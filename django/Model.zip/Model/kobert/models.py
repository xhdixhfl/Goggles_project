from django.db import models

# Create your models here.
class DBdata(models.Model):
 idx = models.AutoField(primary_key=True)
 cate = models.CharField(max_length=25)
 brand = models.CharField(max_length=50)
 pname = models.CharField(max_length=500)
 price = models.CharField(max_length=100)
 tstar = models.FloatField(blank=True, null=True)
 star = models.IntegerField(blank=True, null=True)
 keyword = models.CharField(max_length=500, null=True, blank=True)
 review = models.TextField(null=True, blank=True)


class Test(models.Model):
 idx = models.AutoField(primary_key=True)
 pname = models.CharField(max_length=50)
 query = models.CharField(max_length=100)
 score = models.FloatField(max_length=25)


 #
 # name = models.CharField(max_length=50, blank=True, null=True)
 # tel= models.CharField(max_length=50, blank=True, null=True)
 # email= models.CharField(max_length=50, blank=True, null=True)
 # address= models.CharField(max_length=500, blank=True, null=True)
"""config URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from kobert import views
from django.contrib import admin
from django.urls import path

urlpatterns = [
    # kobert 첫페이지
    path("", views.home),
    path("write", views.write),
    path("insert", views.insert),
    path("transfer2", views.transfer2),  # prac2함수
    path("transfer", views.transfer),
    path("transfer3", views.transfer3),
    path("prac", views.prac, name="trans_info"),
    path('prac2', views.prac2,  name="info"),
    path('prac3', views.prac3, name='info3'),
    # path("play", views.play),

]

from django.shortcuts import render, redirect
from kobert.models import DBdata
from kobert.models import Test
# import function
from sentence_transformers import SentenceTransformer, util
import numpy as np
import func3
import func4



# Create your views here.

def home(request):
    items = DBdata.objects.order_by('pname')
    texts = DBdata.objects.order_by('review')

    return render(request, 'kobert/home.html',
                  {'products':len(items), 'review_count': len(texts)})


def write(request):
    return render(request, 'kobert/write.html')

#상품 등록
def insert(request):

    prod = DBdata(brand= request.POST['brand'], cate= request.POST['cate'] ,\
                  pname=request.POST['pname'], price = request.POST['price'])
    prod.save()
    return redirect('/kobert')

# 리뷰 검색내용 전달 함수

# def transfer(request):  원본
#     cate = request.GET.get('cate')
#     text = request.GET.get('text')
#     trans_info = {
#         'cate': cate,
#         'query': text
#     }
#     return render(request, 'kobert/detail.html', trans_info)
def transfer(request):
    cate = request.POST.get('cate')
    text = request.POST.get('query')
    trans_info = {
        'cate': cate,
        'review': text
    }
    return render(request, 'kobert/detail.html', trans_info)

def transfer2(request):
    # cate = request.POST.get('cate')
    text = request.POST.get('query')
    trans_info = {
        'review': text
    }
    return render(request, 'kobert/detail2.html', trans_info)

def transfer3(request):
    # cate = request.POST.get('cate')
    text = request.POST.get('query')
    trans_info = {
        'review': text
    }
    return render(request, 'kobert/detail3.html', trans_info)


# def play(request):
#     # if request.method == 'POST':
#     no = 2
#     query = '촉촉한 아빠 화장품'
#     answer = func3.all(no, query)
#     info = {
#             'cate': no,
#             'query': query,
#             'ans1':answer[0],
#             'ans2':answer[1],
#             'ans3':answer[2],
#             'ans4':answer[3],
#             'ans5':answer[-1]
#         }
#     return render(request, 'kobert/test.html',info)

def prac(request):
    if request.method == 'POST':
        no = int(request.POST['cate'])
        query = str(request.POST.get('query'))
        answer = func3.all(no, query)
        print(answer[0])
        info = {
            'cate': no,
            'query': query,
            'ans1':answer[0],
            'ans2':answer[1],
            'ans3':answer[2],
            'ans4':answer[3],
            'ans5':answer[-1]
        }
    return render(request, 'kobert/test.html',info)

# def prac2(request):  원본$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#     if request.method == 'POST':
#         query = str(request.POST.get('query'))
#         answer = func4.all2(query)
#
#         info = {
#             'query': query,
#             'ans1':answer[0],
#             'ans2':answer[1],
#             'ans3':answer[2],
#             'ans4':answer[3],
#             'ans5':answer[-1]
#         }
#     return render(request, 'kobert/test.html',info)

def prac2(request):    # 원소별로 리스트 저장한 함수 부른거
    if request.method == 'POST':
        query = str(request.POST.get('query'))
        answer = func4.all2(query)

    info = {
            'query': query,
            'answer': answer
        }
    return render(request, 'kobert/test2.html', info)




def prac3(request):    # 원소별로 리스트 저장한 함수 부른거
    if request.method == 'POST':
        query = str(request.POST.get('query'))
        # answer = func4.all2(query)
        pn, rv, sc = func4.all4(query)

    info = {
            'query': query,
            'pname': pn,
            'review': rv,
            'score' : sc
        }
    # return render(request, 'kobert/test3.html', info)
    return
# def prac3(request):
#     if request.method == 'POST':
#         query = str(request.POST.get('query'))
#         # answer = func4.all2(query)
#         x = func4.all2(query)
#
#         form = Test(request.POST)
#         if form.is_valid():
#             test = form.save(commit=False)
#             test.pname = pn
#             test.review = rv
#             test.score = sc
#         info = {
#             'query': query,
#             'pname': pn,
#             'review': rv,
#             'sc' : score
#         }
#     return render(request, 'kobert/test2.html', info)

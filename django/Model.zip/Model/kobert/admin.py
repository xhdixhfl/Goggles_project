from django.contrib import admin
from kobert.models import DBdata

class ShowDBdata(admin.ModelAdmin):
    # 관리자 페이지에 표시할 내용
    list_display = ('idx', 'cate','brand','pname','price','tstar','review')

admin.site.register(DBdata, ShowDBdata)
# Register your models here.

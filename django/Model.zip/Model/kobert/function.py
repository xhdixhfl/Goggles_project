#!pip install ko-sentence-transformers
from sentence_transformers import SentenceTransformer, models
from ko_sentence_transformers.models import KoBertTransformer

# Model loading
word_embedding_model = KoBertTransformer("monologg/kobert", max_seq_length=75)
pooling_model = models.Pooling(word_embedding_model.get_word_embedding_dimension(), pooling_mode='mean')
model = SentenceTransformer(modules=[word_embedding_model, pooling_model])

from sentence_transformers import SentenceTransformer, util
import numpy as np
import pandas as pd

# embedder loading
embedder = SentenceTransformer("jhgan/ko-sbert-sts")

# 카테고리별 corpus & embedding 불러오기
import torch

ck = torch.load('check_point.tar')

## 전체
tot_corpus = ck['tot_corpus']
tot_embedding = ck['tot_embedding']

## 기초
bas_corpus = ck['bas_corpus']
bas_embedding = ck['bas_embedding']

## 색조
col_corpus = ck['col_corpus']
col_embedding = ck['col_embedding']

## 데이터 연동 고민해야할듯
# data loading
df = pd.read_csv('DBdata.csv')


# 카테고리 선택 함수
def choice_cate(no):
    num = no
    if num == 1:
        embed = tot_embedding
        corpus = tot_corpus

    elif num == 2:
        embed = bas_embedding
        corpus = bas_corpus

    elif num == 3:
        embed = col_embedding
        corpus = col_corpus

    return embed, corpus


## 유사 문장 리스트로 반환
def list_return(query, embed, corpus):
    # 유사도 평가를 위한 작업
    query_embedding = embedder.encode(query, convert_to_tensor=True)
    cos_scores = util.pytorch_cos_sim(query_embedding, embed)[0]
    cos_scores = cos_scores.cpu()
    # 상위 결과 추출
    top_results = np.argpartition(-cos_scores, range(5))[0:5]
    answer = []
    for v, idx in enumerate(top_results[0:5]):
        text = corpus[idx].strip()
        for i in range(3344):  # 전체 df에서
            if text in df['rv'][i]:
                pname = df['pname'][i]
        answer.append([v + 1, pname, text, np.round(cos_scores[idx], 4)])
    return answer


## 최종 실행 함수-> 파라미터로 카테고리 숫자와 쿼리를 받아서 실행됨
def play(no, text):
    embed, corpus = choice_cate(no)
    answer = list_return(text, embed, corpus)
    return answer  # answer가 리스트에 5개의 리스트요소를 담아둠


# # 실행부분
# no = 1
# tt = '촉촉한 로션 찾아줘'
# answer = play(no, tt)
# print(answer)  # 저장된 리스트 확인용

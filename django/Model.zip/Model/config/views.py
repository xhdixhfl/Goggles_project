from django.shortcuts import render

# Create your views here.
def home(request):
    # template 위치 kobert/templates/index.html
    return render(request, 'index.html')